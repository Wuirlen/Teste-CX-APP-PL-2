const aNewFunction = () => {
  // A content here
  console.log("Testando");
};

const Core = {
  aNewFunction,
};

export default Core;
